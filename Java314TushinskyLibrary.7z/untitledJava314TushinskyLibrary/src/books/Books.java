package books;

public class Books {
    private int index;
    private final String bookName;
    private String username = null;
    private boolean state;
    private boolean issue;// статус книги - выдана ли она в библиотеке или нет


    /**
     * Возвращает флаг наличия книги в библиотеке
     * @return true - если книга в библиотеке, иначе false
     */
    public boolean isIssue() {
        return issue;
    }

    /**
     * Устанавливает флаг наличия книги в библиотеке
     * @param issue - true, если книга в библиотеке, иначе false
     */
    public void setIssue(boolean issue) {
        this.issue = issue;
    }


    public Books(String bookName, boolean state, boolean issue) {
        this.bookName = bookName;
        this.state = state;
        this.issue = issue;
    }

    public Books(int index, String bookName, String username, boolean state, boolean issue) {
        this.index = index;
        this.bookName = bookName;
        this.username = username;
        this.state = state;
        this.issue = issue;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public boolean isState() {
        return state;
    }

    public void setState(boolean state) {
        this.state = state;
    }

    public int getIndex() {
        return index;
    }

    public String getBookName() {
        return bookName;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    @Override
    public String toString() {
        return "Books{" +
                "index=" + index +
                ", bookName='" + bookName + '\'' +
                ", issue='" + issue + '\'' +
                ", username='" + username + '\'' +
                '}';
    }
}
